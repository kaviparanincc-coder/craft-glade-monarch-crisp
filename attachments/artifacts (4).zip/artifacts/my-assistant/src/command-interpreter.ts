import { toDateKey, type TaskPriority } from './task-utils.ts';

export type CommandTaskDraft = {
  title: string;
  dueDate: string | null;
  priority: TaskPriority;
  reminderLeadMinutes: number;
  priorityWasExplicit: boolean;
  reminderWasExplicit: boolean;
  dueDateWasExplicit: boolean;
};

export type CommandInterpretation =
  | { kind: 'show-deadlines' }
  | { kind: 'complete-next' }
  | { kind: 'review-task'; draft: CommandTaskDraft }
  | { kind: 'clarify-date'; draft: CommandTaskDraft; question: string }
  | { kind: 'clarify-reminder'; question: string }
  | { kind: 'unsupported' };

export type DateAnswer =
  | { kind: 'resolved'; dueDate: string }
  | { kind: 'ambiguous-year'; question: string }
  | { kind: 'invalid'; question: string }
  | { kind: 'not-a-date' };

type DateToken = { text: string; index: number };
type DateResolution =
  | { kind: 'resolved'; dueDate: string }
  | { kind: 'ambiguous-year'; question: string }
  | { kind: 'invalid'; question: string };

const MONTHS = [
  'january', 'february', 'march', 'april', 'may', 'june',
  'july', 'august', 'september', 'october', 'november', 'december',
];
const MONTH_PATTERN =
  '(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)';
const NUMBER_WORDS: Record<string, number> = {
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
};
const REMINDER_PATTERN =
  /\b(\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten)\s+(minutes?|hours?|days?|weeks?)\s+before\s+(?:(?:its|the|their)\s+)?(?:due\s+date|deadline)\b/i;
const REMINDER_LANGUAGE_CUE =
  /\b(?:(?:\d+|zero|one|two|three|four|five|six|seven|eight|nine|ten|a few|a couple(?: of)?|several)\s+(?:minutes?|hours?|days?|weeks?))\s+before\b/i;

function findDateToken(input: string): DateToken | null {
  const patterns = [
    /\b\d{4}-\d{2}-\d{2}\b/i,
    /\b(?:today|tomorrow)\b/i,
    new RegExp(`\\b${MONTH_PATTERN}\\s+\\d{1,2}(?:st|nd|rd|th)?(?:\\s*,?\\s+\\d{4})?\\b`, 'i'),
    new RegExp(`\\b\\d{1,2}(?:st|nd|rd|th)?\\s+${MONTH_PATTERN}(?:\\s+\\d{4})?\\b`, 'i'),
  ];
  const matches = patterns
    .map((pattern) => {
      const match = pattern.exec(input);
      return match ? { text: match[0], index: match.index } : null;
    })
    .filter((match): match is DateToken => match !== null)
    .sort((left, right) => left.index - right.index);
  return matches[0] ?? null;
}

function monthNumber(name: string): number | undefined {
  const normalized = name.toLowerCase();
  return MONTHS.findIndex((month) => month.startsWith(normalized.slice(0, 3))) + 1 || undefined;
}

function resolveDateToken(token: string, referenceDate: Date): DateResolution {
  const normalized = token.trim().toLowerCase();
  const today = new Date(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate(),
  );

  if (normalized === 'today' || normalized === 'tomorrow') {
    const result = new Date(today);
    if (normalized === 'tomorrow') result.setDate(result.getDate() + 1);
    return { kind: 'resolved', dueDate: toDateKey(result) };
  }

  let year: number | undefined;
  let month: number | undefined;
  let day: number | undefined;
  const isoMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(normalized);
  if (isoMatch) {
    year = Number(isoMatch[1]);
    month = Number(isoMatch[2]);
    day = Number(isoMatch[3]);
  } else {
    const monthFirst = new RegExp(`^(${MONTH_PATTERN})\\s+(\\d{1,2})(?:st|nd|rd|th)?(?:\\s*,?\\s+(\\d{4}))?$`, 'i').exec(token.trim());
    const dayFirst = new RegExp(`^(\\d{1,2})(?:st|nd|rd|th)?\\s+(${MONTH_PATTERN})(?:\\s+(\\d{4}))?$`, 'i').exec(token.trim());
    if (monthFirst) {
      month = monthNumber(monthFirst[1]);
      day = Number(monthFirst[2]);
      year = monthFirst[3] ? Number(monthFirst[3]) : undefined;
    } else if (dayFirst) {
      day = Number(dayFirst[1]);
      month = monthNumber(dayFirst[2]);
      year = dayFirst[3] ? Number(dayFirst[3]) : undefined;
    }
  }

  if (!year && month && day) year = today.getFullYear();
  if (!year || !month || !day) {
    return { kind: 'invalid', question: 'I could not read that date. Please give a date such as “November 15” or “tomorrow”.' };
  }

  const result = new Date(year, month - 1, day);
  if (
    result.getFullYear() !== year ||
    result.getMonth() !== month - 1 ||
    result.getDate() !== day
  ) {
    return { kind: 'invalid', question: 'That is not a valid calendar date. Please enter a valid date such as “November 15”.' };
  }

  if (!isoMatch && !/\b\d{4}\b/.test(token) && result < today) {
    const nextYearDate = new Date(today.getFullYear() + 1, month - 1, day);
    const suggestion = toDateKey(nextYearDate);
    return {
      kind: 'ambiguous-year',
      question: `“${token}” has already passed this year. Did you mean ${suggestion}, or another date? Please include the year.`,
    };
  }

  return { kind: 'resolved', dueDate: toDateKey(result) };
}

function extractReminderLead(input: string): { minutes: number; match: RegExpExecArray } | null {
  const match = REMINDER_PATTERN.exec(input);
  if (!match) return null;
  const amount = /^\d+$/.test(match[1]) ? Number(match[1]) : NUMBER_WORDS[match[1].toLowerCase()];
  const unit = match[2].toLowerCase();
  const multiplier = unit.startsWith('week') ? 10080 : unit.startsWith('day') ? 1440 : unit.startsWith('hour') ? 60 : 1;
  const minutes = amount * multiplier;
  return minutes <= 525600 ? { minutes, match } : null;
}

function stripCommandPrefix(input: string): { body: string; isReminder: boolean } | null {
  const patterns: Array<{ regex: RegExp; isReminder: boolean }> = [
    { regex: /^(?:please\s+)?remind me about\s+/i, isReminder: true },
    { regex: /^(?:please\s+)?remind me to\s+/i, isReminder: true },
    { regex: /^(?:please\s+)?add\s+(?:(?:a|one)\s+)?(?:task\s+(?:to\s+)?)?/i, isReminder: false },
    { regex: /^(?:please\s+)?remember\s+/i, isReminder: false },
    { regex: /^(?:please\s+)?make a note to\s+/i, isReminder: false },
  ];
  for (const pattern of patterns) {
    const match = pattern.regex.exec(input);
    if (match) return { body: input.slice(match[0].length), isReminder: pattern.isReminder };
  }
  return null;
}

function removeDateClause(input: string, token: DateToken): string {
  const before = input.slice(0, token.index);
  const indicator = /\b(?:due(?:\s+on)?|by|on)\s*$/i.exec(before);
  const start = indicator ? before.length - indicator[0].length : token.index;
  return `${input.slice(0, start)} ${input.slice(token.index + token.text.length)}`;
}

function cleanTaskTitle(input: string): string {
  return input
    .replace(/\b(?:high|medium|low)\s+priority\b/gi, ' ')
    .replace(/\bpriority\s*[:=]?\s*(?:high|medium|low)\b/gi, ' ')
    .replace(REMINDER_PATTERN, ' ')
    .replace(/\b(?:its|the|their)\s+(?:due\s+date|deadline)\b/gi, ' ')
    .replace(/\b(?:due(?:\s+on)?|by|on)\s*$/i, ' ')
    .replace(/\s+/g, ' ')
    .replace(/^[\s,.;:—-]+|[\s,.;:—-]+$/g, '')
    .replace(/^(?:to\s+)+/i, '')
    .trim();
}

export function parseCommandDateAnswer(input: string, referenceDate = new Date()): DateAnswer {
  const token = findDateToken(input);
  if (!token) return { kind: 'not-a-date' };
  return resolveDateToken(token.text, referenceDate);
}

export function interpretCommand(input: string, referenceDate = new Date()): CommandInterpretation {
  const clean = input.trim().replace(/[.!?]+$/, '');
  if (!clean) return { kind: 'unsupported' };

  if (
    /^(?:show|list|display|tell me|what (?:are|is)|when (?:are|is))\b/i.test(clean) &&
    /\bdeadlines?\b/i.test(clean)
  ) {
    return { kind: 'show-deadlines' };
  }
  if (/\b(?:finish|complete|check off)\b/i.test(clean)) {
    return { kind: 'complete-next' };
  }

  const command = stripCommandPrefix(clean);
  if (!command) return { kind: 'unsupported' };

  const reminder = extractReminderLead(command.body);
  if (REMINDER_LANGUAGE_CUE.test(command.body) && !reminder) {
    return {
      kind: 'clarify-reminder',
      question: 'I could not read that reminder lead time. Please restate it as “3 days before its deadline” (up to 365 days). Nothing has been saved.',
    };
  }
  const dateToken = findDateToken(command.body);
  const dateResolution = dateToken ? resolveDateToken(dateToken.text, referenceDate) : null;
  const priorityMatch =
    /\b(?:priority\s*[:=]?\s*(high|medium|low)|(high|medium|low)\s+priority)\b/i.exec(command.body);
  const priority = (priorityMatch?.[1] ?? priorityMatch?.[2] ?? 'medium').toLowerCase() as TaskPriority;

  let titleSource = dateToken ? removeDateClause(command.body, dateToken) : command.body;
  if (reminder) titleSource = titleSource.replace(REMINDER_PATTERN, ' ');
  const title = cleanTaskTitle(titleSource);
  if (!title) return { kind: 'unsupported' };
  if (title.length > 160) return { kind: 'unsupported' };

  const draft: CommandTaskDraft = {
    title,
    dueDate: dateResolution?.kind === 'resolved' ? dateResolution.dueDate : null,
    priority,
    reminderLeadMinutes: reminder?.minutes ?? 60,
    priorityWasExplicit: Boolean(priorityMatch),
    reminderWasExplicit: Boolean(reminder),
    dueDateWasExplicit: Boolean(dateToken),
  };

  if (dateResolution?.kind === 'ambiguous-year') {
    return { kind: 'clarify-date', draft, question: dateResolution.question };
  }
  if (dateResolution?.kind === 'invalid') {
    return { kind: 'clarify-date', draft, question: dateResolution.question };
  }

  const mentionsDueDate = /\b(?:due|deadline|by|on)\b/i.test(command.body);
  if (!dateToken && (reminder || command.isReminder || mentionsDueDate)) {
    return {
      kind: 'clarify-date',
      draft,
      question: `What date is “${title}” due? I can understand “today”, “tomorrow”, or a date such as “November 15”.`,
    };
  }

  return { kind: 'review-task', draft };
}
