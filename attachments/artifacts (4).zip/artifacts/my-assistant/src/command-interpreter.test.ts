import assert from 'node:assert/strict';
import test from 'node:test';
import {
  interpretCommand,
  parseCommandDateAnswer,
} from './command-interpreter.ts';
import {
  completeNextIncompleteTask,
  sortTasksForTodayPlan,
  type Task,
} from './task-utils.ts';

const referenceDate = new Date(2026, 9, 21, 12);

test('parses a task title, month/day deadline, explicit priority, and default reminder', () => {
  const result = interpretCommand(
    'Add prepare for exam, due November 15, high priority.',
    referenceDate,
  );
  assert.equal(result.kind, 'review-task');
  if (result.kind !== 'review-task') return;
  assert.deepEqual(result.draft, {
    title: 'prepare for exam',
    dueDate: '2026-11-15',
    priority: 'high',
    reminderLeadMinutes: 60,
    priorityWasExplicit: true,
    reminderWasExplicit: false,
    dueDateWasExplicit: true,
  });
});

test('asks for the missing deadline on a reminder command and keeps its three-day lead', () => {
  const result = interpretCommand(
    'Remind me about my application three days before its deadline.',
    referenceDate,
  );
  assert.equal(result.kind, 'clarify-date');
  if (result.kind !== 'clarify-date') return;
  assert.equal(result.draft.title, 'my application');
  assert.equal(result.draft.dueDate, null);
  assert.equal(result.draft.reminderLeadMinutes, 4320);
  assert.match(result.question, /What date/);
});

test('parses a relative deadline and defaults omitted priority transparently', () => {
  const result = interpretCommand(
    'Add a task to pay the electricity bill tomorrow.',
    referenceDate,
  );
  assert.equal(result.kind, 'review-task');
  if (result.kind !== 'review-task') return;
  assert.equal(result.draft.title, 'pay the electricity bill');
  assert.equal(result.draft.dueDate, '2026-10-22');
  assert.equal(result.draft.priority, 'medium');
  assert.equal(result.draft.priorityWasExplicit, false);
});

test('parses a clarification date and asks before choosing a year for past month/day', () => {
  assert.deepEqual(parseCommandDateAnswer('November 18', referenceDate), {
    kind: 'resolved',
    dueDate: '2026-11-18',
  });
  const result = interpretCommand('Add renew registration, due October 10.', referenceDate);
  assert.equal(result.kind, 'clarify-date');
  if (result.kind !== 'clarify-date') return;
  assert.match(result.question, /include the year/);
  assert.match(result.question, /2027-10-10/);
});

test('asks instead of silently accepting invalid or unsupported due dates', () => {
  const invalid = interpretCommand('Add renew registration, due 2026-02-30.', referenceDate);
  assert.equal(invalid.kind, 'clarify-date');
  if (invalid.kind === 'clarify-date') assert.match(invalid.question, /valid calendar date/);

  const unsupported = interpretCommand('Add prepare slides, due next week.', referenceDate);
  assert.equal(unsupported.kind, 'clarify-date');
  if (unsupported.kind === 'clarify-date') assert.match(unsupported.question, /November 15/);
});

test('asks for an unsupported or out-of-range reminder lead instead of substituting the default', () => {
  const result = interpretCommand('Remind me about insurance 400 days before its deadline.', referenceDate);
  assert.equal(result.kind, 'clarify-reminder');
  if (result.kind === 'clarify-reminder') assert.match(result.question, /Nothing has been saved/);
});

test('recognizes deadline lookup, legacy add, and complete-next commands', () => {
  assert.equal(interpretCommand('Show me my upcoming deadlines.', referenceDate).kind, 'show-deadlines');
  const legacyAdd = interpretCommand('add water the plants', referenceDate);
  assert.equal(legacyAdd.kind, 'review-task');
  if (legacyAdd.kind === 'review-task') assert.equal(legacyAdd.draft.title, 'water the plants');
  assert.equal(interpretCommand('Complete the next task', referenceDate).kind, 'complete-next');
  assert.equal(interpretCommand('Tell me a joke', referenceDate).kind, 'unsupported');
});

test('complete-next completes the first unfinished displayed task despite storage order', () => {
  const storageOrder: Task[] = [
    { id: 'low-first-in-storage', title: 'Low priority', time: '', tag: 'Work', done: false, dueDate: '2026-10-22', priority: 'low', reminderLeadMinutes: 60 },
    { id: 'high-later', title: 'High priority later', time: '', tag: 'Work', done: false, dueDate: '2026-10-24', priority: 'high', reminderLeadMinutes: 60 },
    { id: 'high-sooner', title: 'High priority sooner', time: '', tag: 'Work', done: false, dueDate: '2026-10-22', priority: 'high', reminderLeadMinutes: 60 },
    { id: 'already-done', title: 'Already done', time: '', tag: 'Work', done: true, dueDate: '2026-10-21', priority: 'high', reminderLeadMinutes: 60 },
  ];
  const displayedOrder = sortTasksForTodayPlan(storageOrder);
  assert.deepEqual(
    displayedOrder.map((task) => task.id),
    ['high-sooner', 'high-later', 'low-first-in-storage', 'already-done'],
  );
  assert.equal(interpretCommand('Complete the next task', referenceDate).kind, 'complete-next');

  const result = completeNextIncompleteTask(storageOrder);
  assert.equal(result.completedTask?.id, displayedOrder[0].id);
  assert.equal(result.tasks.find((task) => task.id === 'high-sooner')?.done, true);
  assert.equal(result.tasks.find((task) => task.id === 'low-first-in-storage')?.done, false);
  assert.equal(storageOrder.find((task) => task.id === 'high-sooner')?.done, false);
});
