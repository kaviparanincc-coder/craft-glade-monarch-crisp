export type TaskPriority = 'high' | 'medium' | 'low';

export type Task = {
  id: string;
  title: string;
  time: string;
  tag: string;
  done: boolean;
  dueDate: string | null;
  priority: TaskPriority;
  reminderLeadMinutes: number;
};

export type TaskStorage = {
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
};

const DAY_MS = 24 * 60 * 60 * 1000;
const TASK_STORAGE_KEY = 'my-assistant-tasks';

export function toDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function dateAfterDays(date: Date, days: number): string {
  const result = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  result.setDate(result.getDate() + days);
  return toDateKey(result);
}

export function createSeedTasks(referenceDate = new Date()): Task[] {
  return [
    {
      id: 'email',
      title: 'Reply to Maya about Saturday',
      time: '9:30 AM',
      tag: 'Personal',
      done: true,
      dueDate: dateAfterDays(referenceDate, -1),
      priority: 'low',
      reminderLeadMinutes: 120,
    },
    {
      id: 'pharmacy',
      title: 'Pick up prescription',
      time: 'Before 2 PM',
      tag: 'Errand',
      done: false,
      dueDate: dateAfterDays(referenceDate, 1),
      priority: 'high',
      reminderLeadMinutes: 60,
    },
    {
      id: 'invoice',
      title: 'Send the studio invoice',
      time: 'This afternoon',
      tag: 'Work',
      done: false,
      dueDate: dateAfterDays(referenceDate, 3),
      priority: 'medium',
      reminderLeadMinutes: 1440,
    },
    {
      id: 'walk',
      title: 'Take a proper lunch break',
      time: '12:30 PM',
      tag: 'Wellbeing',
      done: true,
      dueDate: toDateKey(referenceDate),
      priority: 'low',
      reminderLeadMinutes: 30,
    },
  ];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalizeDueDate(value: unknown): string | null {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new Error('A task has an invalid due date.');
  }
  const [year, month, day] = value.split('-').map(Number);
  const parsed = new Date(year, month - 1, day);
  if (
    parsed.getFullYear() !== year ||
    parsed.getMonth() !== month - 1 ||
    parsed.getDate() !== day
  ) {
    throw new Error('A task has an invalid due date.');
  }
  return value;
}

function normalizeTask(value: unknown, fallback?: Task): Task {
  if (!isRecord(value)) throw new Error('A task in this list is invalid.');

  const id = typeof value.id === 'string' ? value.id.trim() : '';
  const title = typeof value.title === 'string' ? value.title.trim() : '';
  if (!id || !title) throw new Error('Every task needs an ID and a title.');
  if (typeof value.done !== 'boolean') {
    throw new Error(`The completion state for "${title}" is invalid.`);
  }

  const priority =
    value.priority === undefined
      ? fallback?.priority ?? 'medium'
      : value.priority;
  if (priority !== 'high' && priority !== 'medium' && priority !== 'low') {
    throw new Error(`The priority for "${title}" is invalid.`);
  }

  const reminderLeadMinutes =
    value.reminderLeadMinutes === undefined
      ? fallback?.reminderLeadMinutes ?? 60
      : value.reminderLeadMinutes;
  if (
    typeof reminderLeadMinutes !== 'number' ||
    !Number.isFinite(reminderLeadMinutes) ||
    reminderLeadMinutes < 0 ||
    reminderLeadMinutes > 525600
  ) {
    throw new Error(`The reminder lead time for "${title}" is invalid.`);
  }

  return {
    id,
    title,
    time:
      typeof value.time === 'string'
        ? value.time
        : fallback?.time ?? '',
    tag:
      typeof value.tag === 'string'
        ? value.tag
        : fallback?.tag ?? 'Personal',
    done: value.done,
    dueDate:
      value.dueDate === undefined && fallback
        ? fallback.dueDate
        : normalizeDueDate(value.dueDate),
    priority,
    reminderLeadMinutes,
  };
}

export function normalizeTaskList(
  value: unknown,
  useLegacySampleDefaults = false,
  referenceDate = new Date(),
): Task[] {
  if (!Array.isArray(value)) throw new Error('The task list must be an array.');
  if (value.length > 1000) throw new Error('A backup can contain at most 1,000 tasks.');

  const sampleDefaults = useLegacySampleDefaults
    ? new Map(createSeedTasks(referenceDate).map((task) => [task.id, task]))
    : new Map<string, Task>();
  const tasks = value.map((task) => {
    const fallback =
      useLegacySampleDefaults && isRecord(task) && typeof task.id === 'string'
        ? sampleDefaults.get(task.id)
        : undefined;
    return normalizeTask(task, fallback);
  });

  if (new Set(tasks.map((task) => task.id)).size !== tasks.length) {
    throw new Error('Task IDs in a backup must be unique.');
  }
  return tasks;
}

export function loadTasksFromStorage(
  storage: TaskStorage | null,
  referenceDate = new Date(),
): Task[] {
  const seeds = createSeedTasks(referenceDate);
  if (!storage) return seeds;
  try {
    const stored = storage.getItem(TASK_STORAGE_KEY);
    return stored
      ? normalizeTaskList(JSON.parse(stored), true, referenceDate)
      : seeds;
  } catch {
    return seeds;
  }
}

export function saveTasksToStorage(storage: TaskStorage, tasks: Task[]): void {
  storage.setItem(TASK_STORAGE_KEY, JSON.stringify(tasks));
}

export function createTaskBackup(tasks: Task[], exportedAt = new Date()): string {
  return JSON.stringify(
    {
      format: 'my-assistant-tasks',
      version: 1,
      exportedAt: exportedAt.toISOString(),
      tasks,
    },
    null,
    2,
  );
}

export function parseTaskBackup(contents: string): Task[] {
  const parsed: unknown = JSON.parse(contents);
  if (Array.isArray(parsed)) return normalizeTaskList(parsed);
  if (
    isRecord(parsed) &&
    Array.isArray(parsed.tasks) &&
    (parsed.format === undefined || parsed.format === 'my-assistant-tasks')
  ) {
    return normalizeTaskList(parsed.tasks);
  }
  throw new Error('This file is not a My Assistant task backup.');
}

export function insertOrUpdateTask(tasks: Task[], task: Task): Task[] {
  const index = tasks.findIndex((item) => item.id === task.id);
  if (index === -1) return [...tasks, task];
  return tasks.map((item) => (item.id === task.id ? task : item));
}

export function removeTask(tasks: Task[], taskId: string): Task[] {
  return tasks.filter((task) => task.id !== taskId);
}

export function toggleTaskCompletion(tasks: Task[], taskId: string): Task[] {
  return tasks.map((task) =>
    task.id === taskId ? { ...task, done: !task.done } : task,
  );
}

export function getDaysRemaining(
  dueDate: string | null,
  referenceDate = new Date(),
): number | null {
  if (!dueDate) return null;
  const [year, month, day] = dueDate.split('-').map(Number);
  const today = Date.UTC(
    referenceDate.getFullYear(),
    referenceDate.getMonth(),
    referenceDate.getDate(),
  );
  return (Date.UTC(year, month - 1, day) - today) / DAY_MS;
}

export function formatDaysRemaining(
  dueDate: string | null,
  referenceDate = new Date(),
): string {
  const days = getDaysRemaining(dueDate, referenceDate);
  if (days === null) return 'No due date';
  if (days < 0) return `Overdue by ${Math.abs(days)} day${days === -1 ? '' : 's'}`;
  if (days === 0) return 'Due today';
  if (days === 1) return 'Tomorrow';
  return `In ${days} days`;
}

export function formatDate(dueDate: string): string {
  const [year, month, day] = dueDate.split('-').map(Number);
  return new Intl.DateTimeFormat(undefined, {
    month: 'short',
    day: 'numeric',
    year: year === new Date().getFullYear() ? undefined : 'numeric',
  }).format(new Date(year, month - 1, day));
}

export function formatReminderLead(minutes: number): string {
  if (minutes === 0) return 'At due time';
  if (minutes % 1440 === 0) {
    const days = minutes / 1440;
    return `${days} day${days === 1 ? '' : 's'} before`;
  }
  if (minutes % 60 === 0) {
    const hours = minutes / 60;
    return `${hours} hour${hours === 1 ? '' : 's'} before`;
  }
  return `${minutes} minute${minutes === 1 ? '' : 's'} before`;
}

export function getDeadlineKind(
  dueDate: string | null,
  referenceDate = new Date(),
): 'overdue' | 'today' | 'upcoming' | 'later' | 'none' {
  const days = getDaysRemaining(dueDate, referenceDate);
  if (days === null) return 'none';
  if (days < 0) return 'overdue';
  if (days === 0) return 'today';
  return days <= 7 ? 'upcoming' : 'later';
}

const PRIORITY_RANK: Record<TaskPriority, number> = {
  high: 0,
  medium: 1,
  low: 2,
};

function compareDeadlineAscending(left: Task, right: Task): number {
  if (left.dueDate === null && right.dueDate !== null) return 1;
  if (left.dueDate !== null && right.dueDate === null) return -1;
  return (left.dueDate ?? '').localeCompare(right.dueDate ?? '');
}

function comparePriorityThenDeadline(left: Task, right: Task): number {
  return (
    PRIORITY_RANK[left.priority] - PRIORITY_RANK[right.priority] ||
    compareDeadlineAscending(left, right) ||
    left.title.localeCompare(right.title)
  );
}

export function sortTasksForTodayPlan(tasks: Task[]): Task[] {
  return [...tasks].sort((left, right) => {
    if (left.done !== right.done) return left.done ? 1 : -1;
    return comparePriorityThenDeadline(left, right);
  });
}

export function completeNextIncompleteTask(
  tasks: Task[],
): { tasks: Task[]; completedTask: Task | null } {
  const next = sortTasksForTodayPlan(tasks).find((task) => !task.done);
  if (!next) return { tasks, completedTask: null };
  return {
    tasks: tasks.map((task) => task.id === next.id ? { ...task, done: true } : task),
    completedTask: next,
  };
}

export function deriveUpcomingDeadlines(tasks: Task[]): Task[] {
  return tasks
    .filter((task) => !task.done && task.dueDate)
    .sort((left, right) => {
      return compareDeadlineAscending(left, right) ||
        PRIORITY_RANK[left.priority] - PRIORITY_RANK[right.priority] ||
        left.title.localeCompare(right.title);
    });
}

export function deriveAttentionTasks(
  tasks: Task[],
  referenceDate = new Date(),
): Task[] {
  return tasks
    .filter((task) => {
      if (task.done) return false;
      const days = getDaysRemaining(task.dueDate, referenceDate);
      return days !== null && days < 0
        ? true
        : task.priority === 'high' && (days === null || days <= 2);
    })
    .sort((left, right) => {
      const leftOverdue = getDaysRemaining(left.dueDate, referenceDate)! < 0;
      const rightOverdue = getDaysRemaining(right.dueDate, referenceDate)! < 0;
      if (leftOverdue !== rightOverdue) return leftOverdue ? -1 : 1;
      if (leftOverdue && rightOverdue) {
        return compareDeadlineAscending(left, right) ||
          PRIORITY_RANK[left.priority] - PRIORITY_RANK[right.priority] ||
          left.title.localeCompare(right.title);
      }
      return comparePriorityThenDeadline(left, right);
    });
}
