import { type ChangeEvent, type FormEvent, type ReactNode } from 'react';
import { useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { AlarmClock, ArrowRight, CalendarDays, Check, CheckCheck, ChevronRight, CircleHelp, CloudSun, Download, Edit2, House, ListChecks, MoreHorizontal, Plus, Settings2, Sparkles, Sun, Trash2, Upload, X } from 'lucide-react';
import {
  interpretCommand,
  parseCommandDateAnswer,
  type CommandTaskDraft,
} from './command-interpreter';
import {
  completeNextIncompleteTask,
  createTaskBackup,
  deriveAttentionTasks,
  deriveUpcomingDeadlines,
  formatDate,
  formatDaysRemaining,
  formatReminderLead,
  getDeadlineKind,
  insertOrUpdateTask,
  loadTasksFromStorage,
  parseTaskBackup,
  removeTask,
  saveTasksToStorage,
  sortTasksForTodayPlan,
  toggleTaskCompletion,
  toDateKey,
  type Task,
  type TaskPriority,
} from './task-utils';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

type Preferences = { instructions: string; reminders: boolean; reminderTime: string };
type ReminderUnit = 'minutes' | 'hours' | 'days';
type TaskDraft = {
  title: string;
  time: string;
  tag: string;
  dueDate: string;
  priority: TaskPriority;
  reminderValue: string;
  reminderUnit: ReminderUnit;
};
type PendingCommandReview = { draft: CommandTaskDraft; existingTaskId?: string };
type PendingDateClarification = { draft: CommandTaskDraft; existingTaskId?: string };

function draftFromTask(task?: Task): TaskDraft {
  if (!task) {
    return {
      title: '',
      time: '',
      tag: 'Personal',
      dueDate: toDateKey(new Date()),
      priority: 'medium',
      reminderValue: '1',
      reminderUnit: 'hours',
    };
  }
  const minutes = task.reminderLeadMinutes;
  if (minutes % 1440 === 0 && minutes > 0) {
    return { ...task, dueDate: task.dueDate ?? '', reminderValue: String(minutes / 1440), reminderUnit: 'days' };
  }
  if (minutes % 60 === 0 && minutes > 0) {
    return { ...task, dueDate: task.dueDate ?? '', reminderValue: String(minutes / 60), reminderUnit: 'hours' };
  }
  return { ...task, dueDate: task.dueDate ?? '', reminderValue: String(minutes), reminderUnit: 'minutes' };
}

function Home() {
  const [tasks, setTasks] = useState<Task[]>(() =>
    loadTasksFromStorage(typeof localStorage === 'undefined' ? null : localStorage),
  );
  const [preferences, setPreferences] = useState<Preferences>(() => {
    try { const stored = localStorage.getItem('my-assistant-settings'); return stored ? JSON.parse(stored) as Preferences : { instructions: '', reminders: true, reminderTime: '8:00 AM' }; } catch { return { instructions: '', reminders: true, reminderTime: '8:00 AM' }; }
  });
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [draftPreferences, setDraftPreferences] = useState(preferences);
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [taskDraft, setTaskDraft] = useState<TaskDraft>(() => draftFromTask());
  const [command, setCommand] = useState('');
  const [response, setResponse] = useState('');
  const [pendingCommandReview, setPendingCommandReview] = useState<PendingCommandReview | null>(null);
  const [pendingDateClarification, setPendingDateClarification] = useState<PendingDateClarification | null>(null);
  const [toast, setToast] = useState('');
  const [today, setToday] = useState(() => new Date());
  const restoreInputRef = useRef<HTMLInputElement>(null);
  const completed = useMemo(() => tasks.filter((task) => task.done).length, [tasks]);
  const todayPlanTasks = useMemo(() => sortTasksForTodayPlan(tasks), [tasks]);
  const visibleDeadlines = useMemo(() => deriveUpcomingDeadlines(tasks), [tasks]);
  const visibleAttention = useMemo(() => deriveAttentionTasks(tasks, today), [tasks, today]);

  useEffect(() => {
    try {
      if (typeof localStorage !== 'undefined') saveTasksToStorage(localStorage, tasks);
    } catch {
      setToast('Tasks could not be saved on this device. Export a backup before closing.');
    }
  }, [tasks]);
  useEffect(() => { localStorage.setItem('my-assistant-settings', JSON.stringify(preferences)); }, [preferences]);
  useEffect(() => {
    const timer = window.setInterval(() => setToday(new Date()), 60_000);
    return () => window.clearInterval(timer);
  }, []);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const toggleTask = (id: string) => setTasks((items) => toggleTaskCompletion(items, id));
  const openSettings = () => { setDraftPreferences(preferences); setSettingsOpen(true); };
  const saveSettings = () => {
    setPreferences(draftPreferences);
    setSettingsOpen(false);
    setToast('Your preferences are saved on this device.');
  };
  const openNewTask = () => {
    setEditingTaskId(null);
    setTaskDraft(draftFromTask());
    setTaskModalOpen(true);
  };
  const openTaskEditor = (task: Task) => {
    setEditingTaskId(task.id);
    setTaskDraft(draftFromTask(task));
    setTaskModalOpen(true);
  };
  const saveTask = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const title = taskDraft.title.trim();
    const reminderValue = Number(taskDraft.reminderValue);
    const unitMultiplier = taskDraft.reminderUnit === 'days' ? 1440 : taskDraft.reminderUnit === 'hours' ? 60 : 1;
    const reminderLeadMinutes = Math.round(reminderValue * unitMultiplier);
    if (!title) {
      setToast('Add a title before saving this task.');
      return;
    }
    if (!Number.isFinite(reminderValue) || reminderValue < 0 || reminderLeadMinutes > 525600) {
      setToast('Choose a reminder lead time between 0 and 365 days.');
      return;
    }
    const existing = tasks.find((task) => task.id === editingTaskId);
    const task: Task = {
      id: editingTaskId ?? `task-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`,
      title,
      time: taskDraft.time.trim(),
      tag: taskDraft.tag.trim() || 'Personal',
      done: existing?.done ?? false,
      dueDate: taskDraft.dueDate || null,
      priority: taskDraft.priority,
      reminderLeadMinutes,
    };
    setTasks((items) => insertOrUpdateTask(items, task));
    setTaskModalOpen(false);
    setToast(editingTaskId ? 'Task updated.' : 'Task added to your plan.');
  };
  const deleteTask = (task: Task) => {
    if (!window.confirm(`Delete “${task.title}”? This cannot be undone unless you have a backup.`)) return;
    setTasks((items) => removeTask(items, task.id));
    setToast('Task deleted.');
  };
  const exportTasks = () => {
    try {
      const blob = new Blob([createTaskBackup(tasks)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `my-assistant-tasks-${toDateKey(new Date())}.json`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setToast('Task backup downloaded.');
    } catch {
      setToast('Could not create a backup file.');
    }
  };
  const restoreTasks = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = '';
    if (!file) return;
    try {
      const restoredTasks = parseTaskBackup(await file.text());
      if (!window.confirm(`Restore ${restoredTasks.length} task${restoredTasks.length === 1 ? '' : 's'}? This replaces the current task list.`)) return;
      setTasks(restoredTasks);
      setToast('Tasks restored from backup.');
    } catch (error) {
      setToast(error instanceof Error ? error.message : 'This backup could not be restored.');
    }
  };
  const confirmCommandTask = () => {
    if (!pendingCommandReview) return;
    const { draft, existingTaskId } = pendingCommandReview;
    const existing = existingTaskId ? tasks.find((task) => task.id === existingTaskId) : undefined;
    const task: Task = {
      id: existing?.id ?? `added-${globalThis.crypto?.randomUUID?.() ?? Date.now()}`,
      title: draft.title,
      time: existing?.time ?? 'Added from command',
      tag: existing?.tag ?? 'From command',
      done: existing?.done ?? false,
      dueDate: draft.dueDate,
      priority: draft.priority,
      reminderLeadMinutes: draft.reminderLeadMinutes,
    };
    setTasks((items) => insertOrUpdateTask(items, task));
    setPendingCommandReview(null);
    setResponse(existing ? `Updated “${task.title}” after your confirmation.` : `Added “${task.title}” to Today's Plan.`);
    setToast(existing ? 'Task updated.' : 'Added to your plan.');
  };
  const submitCommand = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const clean = command.trim();
    if (!clean) return;

    if (pendingDateClarification) {
      const answer = parseCommandDateAnswer(clean, today);
      if (answer.kind === 'resolved') {
        const draft = { ...pendingDateClarification.draft, dueDate: answer.dueDate, dueDateWasExplicit: true };
        setPendingCommandReview({ draft, existingTaskId: pendingDateClarification.existingTaskId });
        setPendingDateClarification(null);
        setResponse(`I understood the deadline as ${formatDate(answer.dueDate)}. Review the task details below before saving.`);
      } else if (answer.kind === 'ambiguous-year' || answer.kind === 'invalid') {
        setResponse(answer.question);
      } else {
        setResponse('Please reply with the deadline date, such as “November 15” or “tomorrow”. Nothing has been saved.');
      }
      setCommand('');
      return;
    }

    const interpretation = interpretCommand(clean, today);
    if (interpretation.kind === 'show-deadlines') {
      const deadlines = deriveUpcomingDeadlines(tasks);
      const visibleLines = deadlines.slice(0, 8).map((task) =>
        `• ${task.title} — ${formatDate(task.dueDate!)} (${formatDaysRemaining(task.dueDate, today)})`,
      );
      const extraCount = deadlines.length - visibleLines.length;
      setResponse(deadlines.length
        ? `Your upcoming deadlines:\n${visibleLines.join('\n')}${extraCount > 0 ? `\n…and ${extraCount} more in the full list.` : ''}`
        : 'You have no open tasks with due dates.');
      window.setTimeout(() => document.getElementById('deadlines')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0);
    } else if (interpretation.kind === 'complete-next') {
      const result = completeNextIncompleteTask(tasks);
      if (result.completedTask) {
        setTasks(result.tasks);
        setResponse(`Checked off “${result.completedTask.title}” in your plan.`);
      } else {
        setResponse('Everything in your plan is already checked off.');
      }
    } else if (interpretation.kind === 'review-task') {
      setPendingCommandReview({ draft: interpretation.draft });
      setResponse('Review the interpreted task details below. It has not been saved yet.');
    } else if (interpretation.kind === 'clarify-date') {
      const normalizeTitle = (title: string) => title.toLocaleLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
      const existing = tasks.find((task) =>
        !task.done && normalizeTitle(task.title) === normalizeTitle(interpretation.draft.title),
      );
      if (existing?.dueDate && !interpretation.draft.dueDateWasExplicit) {
        const draft = {
          ...interpretation.draft,
          title: existing.title,
          dueDate: existing.dueDate,
          priority: interpretation.draft.priorityWasExplicit ? interpretation.draft.priority : existing.priority,
        };
        setPendingCommandReview({ draft, existingTaskId: existing.id });
        setResponse(`I found a matching task due ${formatDate(existing.dueDate)}. Review the reminder update below before saving.`);
      } else {
        setPendingDateClarification({ draft: interpretation.draft, existingTaskId: existing?.id });
        setResponse(interpretation.question);
      }
    } else if (interpretation.kind === 'clarify-reminder') {
      setResponse(interpretation.question);
    } else {
      setResponse('I can add tasks with an optional date, priority, or reminder lead time; show upcoming deadlines; or complete the next unfinished task in Today’s Plan. Try one of the examples below.');
    }
    setCommand('');
  };
  const scrollTo = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  const todayLabel = new Intl.DateTimeFormat('en', { weekday: 'long', month: 'long', day: 'numeric' }).format(today);
  const weekday = new Intl.DateTimeFormat('en', { weekday: 'long' }).format(today).toUpperCase();
  const navItems = [
    { id: 'plan', label: "Today's Plan", icon: ListChecks, count: `${completed}/${tasks.length}` },
    { id: 'deadlines', label: 'Upcoming Deadlines', icon: CalendarDays },
    { id: 'updates', label: 'Personalised Updates', icon: CloudSun },
    { id: 'attention', label: 'Things Needing Attention', icon: CircleHelp, count: String(visibleAttention.length) },
    { id: 'command', label: 'Ask My Assistant', icon: Sparkles },
  ];
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-row">
          <div className="brand-mark"><Sun size={21} strokeWidth={2.2} /></div>
          <div className="brand-copy"><div className="brand-name">my assistant</div><div className="brand-sub">Your day, in hand</div></div>
        </div>
        <div className="nav-caption">Your command centre</div>
        <nav className="side-nav" aria-label="Dashboard sections">
          {navItems.map(({ id, label, icon: Icon, count }, index) => (
            <button className={`side-link ${index === 0 ? 'active' : ''}`} key={id} onClick={() => scrollTo(id)} data-testid={`nav-${id}`} aria-label={`Go to ${label}`}>
              <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{count && <small className="side-count">{count}</small>}
            </button>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="prototype-note">A small local prototype, built to bring the next right thing into focus.</div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="date-label" data-testid="text-current-date">{todayLabel}</div>
          <div className="top-actions">
            <div className="local-pill" data-testid="status-local-prototype"><i className="local-dot" /> Local prototype</div>
            <button className="icon-button" aria-label="Open settings" title="Settings" onClick={openSettings} data-testid="button-open-settings"><Settings2 size={18} /></button>
          </div>
        </header>
        <section className="welcome">
          <div><div className="eyebrow" style={{ color: '#a17d4b' }}>{weekday}, WITH ROOM TO BREATHE</div><h1>Good morning,<br />Jamie.</h1><p>A few things to keep today moving gently forward.</p></div>
          <div className="day-mark" aria-label={`${tasks.length} tasks in your plan`}><div><strong>{String(tasks.length).padStart(2, '0')}</strong><span>things<br />in orbit</span></div></div>
        </section>

        <section className="plan-card" id="plan" data-testid="section-todays-plan">
          <div className="section-heading">
            <div><span className="section-kicker">THE IMPORTANT THINGS, FIRST</span><h2>Today's Plan</h2></div>
            <div className="plan-toolbar">
              <span className="progress-copy" data-testid="status-plan-progress">{completed} of {tasks.length} done</span>
              <div className="task-toolbar">
                <button type="button" className="toolbar-button toolbar-primary" onClick={openNewTask} data-testid="button-add-task"><Plus size={14} /> Add task</button>
                <button type="button" className="toolbar-button" onClick={exportTasks} data-testid="button-export-tasks"><Download size={13} /> Export</button>
                <button type="button" className="toolbar-button" onClick={() => restoreInputRef.current?.click()} data-testid="button-restore-tasks"><Upload size={13} /> Restore</button>
                <input ref={restoreInputRef} className="visually-hidden" type="file" accept=".json,application/json" onChange={restoreTasks} data-testid="input-restore-tasks" aria-label="Choose a My Assistant backup file" />
              </div>
            </div>
          </div>
          <div className="progress-track" aria-label={`${completed} of ${tasks.length} tasks complete`}><div className="progress-fill" style={{ width: `${tasks.length ? completed / tasks.length * 100 : 0}%` }} /></div>
          <div className="task-list">
            {todayPlanTasks.length ? todayPlanTasks.map((task) => {
              const deadlineKind = task.done ? 'none' : getDeadlineKind(task.dueDate, today);
              return (
                <div className={`task-row ${deadlineKind === 'overdue' ? 'task-row-overdue' : ''}`} key={task.id} data-testid={`task-row-${task.id}`}>
                  <button className={`task-check ${task.done ? 'done' : ''}`} aria-label={`${task.done ? 'Mark incomplete' : 'Complete'}: ${task.title}`} onClick={() => toggleTask(task.id)} data-testid={`button-complete-task-${task.id}`}>{task.done && <Check size={14} strokeWidth={3} />}</button>
                  <div className="task-content">
                    <div className={`task-title ${task.done ? 'done' : ''}`} data-testid={`text-task-${task.id}`}>{task.title}</div>
                    <div className="task-meta">
                      {task.time && <span className="task-time">{task.time}</span>}
                      <span className="task-tag">{task.tag}</span>
                      <span className={`priority-label priority-${task.priority}`}>{task.priority} priority</span>
                      <span className={`task-due task-due-${deadlineKind}`} data-testid={`task-due-${task.id}`}>{task.dueDate ? `${formatDate(task.dueDate)} · ${task.done ? 'Completed' : formatDaysRemaining(task.dueDate, today)}` : 'No due date'}</span>
                      <span className="task-reminder" title="Reminder lead time"><AlarmClock size={12} /> {formatReminderLead(task.reminderLeadMinutes)}</span>
                    </div>
                  </div>
                  <div className="task-row-actions">
                    <button type="button" className="small-icon-button" aria-label={`Edit ${task.title}`} title="Edit task" onClick={() => openTaskEditor(task)} data-testid={`button-edit-task-${task.id}`}><Edit2 size={14} /></button>
                    <button type="button" className="small-icon-button delete-icon-button" aria-label={`Delete ${task.title}`} title="Delete task" onClick={() => deleteTask(task)} data-testid={`button-delete-task-${task.id}`}><Trash2 size={14} /></button>
                  </div>
                </div>
              );
            }) : <div className="empty-task-list" data-testid="empty-plan">Your plan is clear. Add a task whenever you are ready.</div>}
          </div>
        </section>

        <div className="content-grid">
          <section className="panel" id="deadlines" data-testid="section-upcoming-deadlines">
            <div className="panel-heading"><div><span className="section-kicker">A LITTLE LOOK AHEAD</span><h3>Upcoming Deadlines</h3></div><span className="tiny-label">{visibleDeadlines.length} due</span></div>
            <div className="deadline-list">
              {visibleDeadlines.length ? visibleDeadlines.map((item) => {
                const kind = getDeadlineKind(item.dueDate, today);
                const [year, month, day] = item.dueDate!.split('-').map(Number);
                const monthLabel = new Intl.DateTimeFormat(undefined, { month: 'short' }).format(new Date(year, month - 1, day)).toUpperCase();
                return (
                  <div className={`deadline-row deadline-${kind}`} key={item.id} data-testid={`deadline-${item.id}`}>
                    <div className="date-block"><b>{day}</b><span>{monthLabel}</span></div>
                    <div className="deadline-copy">
                      <div className="deadline-name">{item.title}</div>
                      <div className="deadline-sub">{item.priority} priority · Reminder {formatReminderLead(item.reminderLeadMinutes)}</div>
                      <span className={`deadline-badge deadline-badge-${kind}`} data-testid={`deadline-status-${item.id}`}>{formatDaysRemaining(item.dueDate, today)}</span>
                    </div>
                    <div className="deadline-actions">
                      <button type="button" className="deadline-complete" onClick={() => { toggleTask(item.id); setToast('Task marked complete.'); }} data-testid={`button-complete-deadline-${item.id}`}>Complete</button>
                      <button type="button" className="small-icon-button" aria-label={`Edit ${item.title}`} onClick={() => openTaskEditor(item)} data-testid={`button-edit-deadline-${item.id}`}><Edit2 size={13} /></button>
                    </div>
                  </div>
                );
              }) : <div className="tiny-label" data-testid="empty-deadlines">No open tasks have a due date.</div>}
            </div>
          </section>

          <section className="panel" id="updates" data-testid="section-personalised-updates">
            <div className="panel-heading"><div><span className="section-kicker">A FEW USEFUL HEADS-UPS</span><h3>Personalised Updates</h3></div><MoreHorizontal size={18} color="#879188" /></div>
            <div className="update-card" data-testid="update-weather">
              <div className="update-top"><span className="update-icon"><CloudSun size={15} /></span><span className="update-source">Around your day · 8:12 AM</span></div>
              <p>Clear skies until late afternoon. A good window for that pharmacy stop on your way home.</p>
            </div>
            <div className="update-card" data-testid="update-home">
              <div className="update-top"><span className="update-icon"><House size={15} /></span><span className="update-source">Home note · 7:40 AM</span></div>
              <p>Recycling goes out tonight. You have a little time before the evening rush.</p>
            </div>
          </section>
        </div>

        <section className="panel attention-panel" id="attention" data-testid="section-things-needing-attention">
          <div className="panel-heading"><div><span className="section-kicker">PRIORITIES FROM YOUR PLAN</span><h3>Things Needing Attention</h3></div><span className="tiny-label">{visibleAttention.length} to look at</span></div>
          <div className="attention-list">
            {visibleAttention.length ? visibleAttention.map((item) => (
              <div className={`attention-row ${getDeadlineKind(item.dueDate, today) === 'overdue' ? 'attention-row-overdue' : ''}`} key={item.id} data-testid={`attention-item-${item.id}`}>
                <div className="attention-symbol">{getDeadlineKind(item.dueDate, today) === 'overdue' ? <CalendarDays size={16} /> : <CircleHelp size={16} />}</div>
                <div className="attention-text"><b>{item.title}</b><span className={getDeadlineKind(item.dueDate, today) === 'overdue' ? 'attention-overdue-text' : ''}>{item.dueDate ? `${formatDaysRemaining(item.dueDate, today)} · ${item.priority} priority` : 'High priority · No due date'}</span></div>
                <div className="attention-actions">
                  <button type="button" className="text-action" onClick={() => { toggleTask(item.id); setToast('Task marked complete.'); }} data-testid={`button-complete-attention-${item.id}`}>Complete<ChevronRight size={13} style={{ verticalAlign: 'middle' }} /></button>
                  <button type="button" className="text-action" onClick={() => openTaskEditor(item)} data-testid={`button-edit-attention-${item.id}`}>Edit</button>
                </div>
              </div>
            )) : <div className="attention-row" data-testid="empty-attention"><div className="attention-symbol"><CheckCheck size={16} /></div><div className="attention-text"><b>Nothing asking for you right now.</b><span>That's a good place to be.</span></div></div>}
          </div>
        </section>

        <section className="command-panel" id="command" data-testid="section-ai-command">
          <div className="panel-heading"><div><span className="section-kicker" style={{ color: '#bac7bb' }}>A SMALL LOCAL DEMO</span><h3>What can I take off your mind?</h3></div><Sparkles size={19} color="#edbd77" /></div>
          <p className="command-lead">Local command interpreter only; no AI service is connected. Supports adding tasks with a deadline, priority, or reminder lead time; showing upcoming deadlines; and completing the next open task.</p>
          <p className="command-examples">Try “Add prepare for exam, due November 15, high priority”, “Remind me about my application three days before its deadline”, “Add a task to pay the electricity bill tomorrow”, “Show me my upcoming deadlines”, or “Complete the next task”. Dates: today, tomorrow, Month Day, or YYYY-MM-DD. Priorities: high, medium, low. Reminder leads: numeric or zero–ten word numbers in minutes, hours, days, or weeks before the deadline.</p>
          <form className="command-form" onSubmit={submitCommand}>
            <input className="command-input" value={command} onChange={(event) => setCommand(event.target.value)} placeholder={pendingDateClarification ? 'Enter a date, such as November 15' : 'Type a task or ask to show your deadlines'} aria-label="Write a command" disabled={Boolean(pendingCommandReview)} data-testid="input-assistant-command" />
            <button className="send-button" type="submit" disabled={Boolean(pendingCommandReview)} data-testid="button-submit-command">Send <ArrowRight size={15} /></button>
          </form>
          {response && <div className="demo-response" role="status" data-testid="status-command-response">{response}</div>}
          {pendingDateClarification && <div className="command-review-actions">
            <button type="button" className="command-review-cancel" onClick={() => { setPendingDateClarification(null); setResponse('Request cancelled. No task was saved.'); }} data-testid="button-cancel-command-clarification">Cancel request</button>
          </div>}
          {pendingCommandReview && <div className="command-task-review" role="group" aria-label="Review task details before saving" data-testid="command-task-review">
            <div className="command-task-review-copy">
              <b>{pendingCommandReview.draft.title}</b>
              <span>
                {pendingCommandReview.draft.dueDate ? `Due ${formatDate(pendingCommandReview.draft.dueDate)}` : 'No due date'}
                {' · '}{pendingCommandReview.draft.priority[0].toUpperCase() + pendingCommandReview.draft.priority.slice(1)} priority{pendingCommandReview.draft.priorityWasExplicit ? '' : ' (default)'}
                {' · Reminder '}{formatReminderLead(pendingCommandReview.draft.reminderLeadMinutes)}{pendingCommandReview.draft.reminderWasExplicit ? '' : ' (default)'}
              </span>
            </div>
            <div className="command-review-actions">
              <button type="button" className="command-review-confirm" onClick={confirmCommandTask} data-testid="button-confirm-command-task">{pendingCommandReview.existingTaskId ? 'Update task' : 'Add task'}</button>
              <button type="button" className="command-review-cancel" onClick={() => { setPendingCommandReview(null); setResponse('Task discarded. Nothing was saved.'); }} data-testid="button-cancel-command-task">Cancel</button>
            </div>
          </div>}
        </section>
        <footer className="page-foot"><span>My Assistant · A personal command centre</span><span>Sample data · Stored locally on this device</span></footer>
      </main>

      {taskModalOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setTaskModalOpen(false); }}>
        <section className="settings-modal task-modal" role="dialog" aria-modal="true" aria-labelledby="task-editor-title" data-testid="dialog-task-editor">
          <div className="modal-title-row">
            <div><h2 id="task-editor-title">{editingTaskId ? 'Edit task.' : 'Add to your plan.'}</h2><p>Choose a due date, priority and reminder lead time.</p></div>
            <button type="button" className="icon-button" aria-label="Close task editor" onClick={() => setTaskModalOpen(false)} data-testid="button-close-task-editor"><X size={17} /></button>
          </div>
          <form onSubmit={saveTask}>
            <label className="settings-label" htmlFor="task-title">Task</label>
            <input id="task-title" className="settings-input" value={taskDraft.title} onChange={(event) => setTaskDraft((current) => ({ ...current, title: event.target.value }))} maxLength={160} required autoFocus data-testid="input-task-title" />
            <div className="task-form-grid">
              <div>
                <label className="settings-label" htmlFor="task-due-date">Due date</label>
                <input id="task-due-date" className="settings-input" type="date" value={taskDraft.dueDate} onChange={(event) => setTaskDraft((current) => ({ ...current, dueDate: event.target.value }))} data-testid="input-task-due-date" />
              </div>
              <div>
                <label className="settings-label" htmlFor="task-priority">Priority</label>
                <select id="task-priority" className="settings-select" value={taskDraft.priority} onChange={(event) => setTaskDraft((current) => ({ ...current, priority: event.target.value as TaskPriority }))} data-testid="select-task-priority">
                  <option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option>
                </select>
              </div>
              <div>
                <label className="settings-label" htmlFor="task-time">Time or note</label>
                <input id="task-time" className="settings-input" value={taskDraft.time} onChange={(event) => setTaskDraft((current) => ({ ...current, time: event.target.value }))} placeholder="Optional" maxLength={80} data-testid="input-task-time" />
              </div>
              <div>
                <label className="settings-label" htmlFor="task-tag">Category</label>
                <input id="task-tag" className="settings-input" value={taskDraft.tag} onChange={(event) => setTaskDraft((current) => ({ ...current, tag: event.target.value }))} placeholder="Personal" maxLength={40} data-testid="input-task-category" />
              </div>
            </div>
            <label className="settings-label" htmlFor="task-reminder-value">Remind me before the due date</label>
            <div className="reminder-input-row">
              <input id="task-reminder-value" className="settings-input" type="number" min="0" max={taskDraft.reminderUnit === 'days' ? 365 : taskDraft.reminderUnit === 'hours' ? 8760 : 525600} step="any" value={taskDraft.reminderValue} onChange={(event) => setTaskDraft((current) => ({ ...current, reminderValue: event.target.value }))} required data-testid="input-task-reminder-lead" />
              <select className="settings-select" aria-label="Reminder lead time unit" value={taskDraft.reminderUnit} onChange={(event) => setTaskDraft((current) => ({ ...current, reminderUnit: event.target.value as ReminderUnit }))} data-testid="select-task-reminder-unit">
                <option value="minutes">Minutes</option><option value="hours">Hours</option><option value="days">Days</option>
              </select>
            </div>
            <p className="form-note">The lead time is saved with this task. This local app does not send device notifications.</p>
            <div className="modal-actions">
              <button type="button" className="secondary-button" onClick={() => setTaskModalOpen(false)} data-testid="button-cancel-task">Cancel</button>
              <button type="submit" className="save-button" data-testid="button-save-task">{editingTaskId ? 'Save changes' : 'Add task'}</button>
            </div>
          </form>
        </section>
      </div>}
      {settingsOpen && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSettingsOpen(false); }}>
        <section className="settings-modal" role="dialog" aria-modal="true" aria-labelledby="settings-title" data-testid="dialog-settings">
          <div className="modal-title-row"><div><h2 id="settings-title">Make it yours.</h2><p>Your preferences stay on this device.</p></div><button className="icon-button" aria-label="Close settings" onClick={() => setSettingsOpen(false)} data-testid="button-close-settings"><X size={17} /></button></div>
          <label className="settings-label" htmlFor="custom-instructions">Custom instructions</label>
          <textarea id="custom-instructions" className="settings-textarea" value={draftPreferences.instructions} onChange={(event) => setDraftPreferences((current) => ({ ...current, instructions: event.target.value }))} placeholder="For example: Keep weekday plans light, and remind me to make space for lunch." data-testid="input-custom-instructions" />
          <div className="setting-toggle"><div><strong>Daily reminder</strong><div className="deadline-sub">A gentle nudge to check your plan</div></div><button role="switch" aria-checked={draftPreferences.reminders} className={`toggle-button ${draftPreferences.reminders ? 'on' : ''}`} onClick={() => setDraftPreferences((current) => ({ ...current, reminders: !current.reminders }))} data-testid="toggle-daily-reminder"><span /></button></div>
          <label className="settings-label" htmlFor="reminder-time">Reminder time</label>
          <select id="reminder-time" className="settings-select" value={draftPreferences.reminderTime} onChange={(event) => setDraftPreferences((current) => ({ ...current, reminderTime: event.target.value }))} disabled={!draftPreferences.reminders} data-testid="select-reminder-time">
            <option>7:00 AM</option><option>8:00 AM</option><option>9:00 AM</option><option>6:00 PM</option>
          </select>
          <div className="modal-actions"><button className="secondary-button" onClick={() => setSettingsOpen(false)} data-testid="button-cancel-settings">Cancel</button><button className="save-button" onClick={saveSettings} data-testid="button-save-settings">Save preferences</button></div>
        </section>
      </div>}
      {toast && <div className="toast-message" role="status" data-testid="status-toast">{toast}</div>}
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
