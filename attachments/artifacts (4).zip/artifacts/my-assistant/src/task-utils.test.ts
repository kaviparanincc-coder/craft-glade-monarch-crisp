import assert from 'node:assert/strict';
import test from 'node:test';
import {
  createTaskBackup,
  createSeedTasks,
  deriveAttentionTasks,
  deriveUpcomingDeadlines,
  formatDaysRemaining,
  getDeadlineKind,
  insertOrUpdateTask,
  loadTasksFromStorage,
  normalizeTaskList,
  parseTaskBackup,
  removeTask,
  saveTasksToStorage,
  sortTasksForTodayPlan,
  toggleTaskCompletion,
  toDateKey,
  type Task,
} from './task-utils.ts';

const referenceDate = new Date(2026, 9, 21, 12);

function task(overrides: Partial<Task> = {}): Task {
  return {
    id: 'task-1',
    title: 'Review draft',
    time: '',
    tag: 'Work',
    done: false,
    dueDate: '2026-10-22',
    priority: 'medium',
    reminderLeadMinutes: 60,
    ...overrides,
  };
}

test('seed tasks include a mix of today, future, and completed dates', () => {
  const tasks = createSeedTasks(referenceDate);
  assert.equal(tasks.length, 4);
  assert.equal(tasks.find((item) => item.id === 'pharmacy')?.dueDate, '2026-10-22');
  assert.equal(tasks.find((item) => item.id === 'walk')?.dueDate, '2026-10-21');
});

test('deadline labels calculate overdue, today, tomorrow, and future days', () => {
  assert.equal(formatDaysRemaining('2026-10-20', referenceDate), 'Overdue by 1 day');
  assert.equal(formatDaysRemaining('2026-10-21', referenceDate), 'Due today');
  assert.equal(formatDaysRemaining('2026-10-22', referenceDate), 'Tomorrow');
  assert.equal(formatDaysRemaining('2026-10-24', referenceDate), 'In 3 days');
  assert.equal(formatDaysRemaining(null, referenceDate), 'No due date');
  assert.equal(getDeadlineKind('2026-10-20', referenceDate), 'overdue');
  assert.equal(getDeadlineKind('2026-10-21', referenceDate), 'today');
  assert.equal(getDeadlineKind('2026-10-25', referenceDate), 'upcoming');
  assert.equal(getDeadlineKind('2026-11-01', referenceDate), 'later');
});

test('deadline and attention sections derive from the same incomplete tasks', () => {
  const tasks = [
    task({ id: 'overdue', title: 'Overdue task', dueDate: '2026-10-20' }),
    task({ id: 'urgent', title: 'Urgent task', priority: 'high' }),
    task({ id: 'later', title: 'Later task', dueDate: '2026-11-01' }),
    task({ id: 'done', title: 'Completed task', done: true, dueDate: '2026-10-20' }),
    task({ id: 'undated', title: 'Undated task', dueDate: null, priority: 'low' }),
  ];

  assert.deepEqual(
    deriveUpcomingDeadlines(tasks).map((item) => item.id),
    ['overdue', 'urgent', 'later'],
  );
  assert.deepEqual(
    deriveAttentionTasks(tasks, referenceDate).map((item) => item.id),
    ['overdue', 'urgent'],
  );
});

test('Today’s Plan sorts incomplete tasks by priority, then deadline, before completed tasks', () => {
  const tasks = [
    task({ id: 'low-no-date', priority: 'low', dueDate: null }),
    task({ id: 'done-medium', priority: 'medium', done: true, dueDate: '2026-10-20' }),
    task({ id: 'medium-later', priority: 'medium', dueDate: '2026-10-24' }),
    task({ id: 'high-later', priority: 'high', dueDate: '2026-10-24' }),
    task({ id: 'low-overdue', priority: 'low', dueDate: '2026-10-19' }),
    task({ id: 'high-overdue', priority: 'high', dueDate: '2026-10-20' }),
    task({ id: 'high-no-date', priority: 'high', dueDate: null }),
    task({ id: 'medium-sooner', priority: 'medium', dueDate: '2026-10-22' }),
    task({ id: 'done-high', priority: 'high', done: true, dueDate: '2026-10-22' }),
  ];

  assert.deepEqual(
    sortTasksForTodayPlan(tasks).map((item) => item.id),
    [
      'high-overdue',
      'high-later',
      'high-no-date',
      'medium-sooner',
      'medium-later',
      'low-overdue',
      'low-no-date',
      'done-high',
      'done-medium',
    ],
  );
});

test('deadline ties use priority and attention puts overdue tasks first', () => {
  const tasks = [
    task({ id: 'medium-today', dueDate: '2026-10-21', priority: 'medium' }),
    task({ id: 'high-today', dueDate: '2026-10-21', priority: 'high' }),
    task({ id: 'low-overdue', dueDate: '2026-10-19', priority: 'low' }),
    task({ id: 'high-overdue', dueDate: '2026-10-20', priority: 'high' }),
    task({ id: 'completed-overdue', dueDate: '2026-10-18', done: true, priority: 'high' }),
  ];

  assert.deepEqual(
    deriveUpcomingDeadlines(tasks).map((item) => item.id),
    ['low-overdue', 'high-overdue', 'high-today', 'medium-today'],
  );
  assert.deepEqual(
    deriveAttentionTasks(tasks, referenceDate).map((item) => item.id),
    ['low-overdue', 'high-overdue', 'high-today'],
  );
});

test('plan ordering recalculates after adding, editing, and completing a task', () => {
  const mediumTask = task({ id: 'medium', priority: 'medium', dueDate: '2026-10-22' });
  const lowTask = task({ id: 'low', priority: 'low', dueDate: '2026-10-21' });
  const initial = [lowTask, mediumTask];
  assert.deepEqual(sortTasksForTodayPlan(initial).map((item) => item.id), ['medium', 'low']);

  const edited = insertOrUpdateTask(initial, {
    ...lowTask,
    priority: 'high',
    dueDate: '2026-10-20',
  });
  assert.deepEqual(sortTasksForTodayPlan(edited).map((item) => item.id), ['low', 'medium']);

  const withNewTask = insertOrUpdateTask(edited, task({
    id: 'new-high',
    priority: 'high',
    dueDate: '2026-10-19',
  }));
  assert.deepEqual(sortTasksForTodayPlan(withNewTask).map((item) => item.id), ['new-high', 'low', 'medium']);

  const completed = toggleTaskCompletion(withNewTask, 'new-high');
  assert.deepEqual(sortTasksForTodayPlan(completed).map((item) => item.id), ['low', 'medium', 'new-high']);
});

test('task add, edit, complete, and delete helpers preserve task identity', () => {
  const original = task();
  const added = task({ id: 'task-2', title: 'Call the clinic' });
  const edited = { ...original, title: 'Review the final draft' };

  const withAdded = insertOrUpdateTask([original], added);
  assert.equal(withAdded.length, 2);
  assert.equal(insertOrUpdateTask(withAdded, edited)[0].title, edited.title);
  assert.equal(toggleTaskCompletion(withAdded, original.id)[0].done, true);
  assert.deepEqual(removeTask(withAdded, original.id).map((item) => item.id), ['task-2']);
});

test('legacy local tasks receive new fields without losing their saved state', () => {
  const tasks = normalizeTaskList(
    [{ id: 'pharmacy', title: 'Pick up prescription', time: 'Before 2 PM', tag: 'Errand', done: true }],
    true,
    referenceDate,
  );
  assert.equal(tasks[0].done, true);
  assert.equal(tasks[0].dueDate, '2026-10-22');
  assert.equal(tasks[0].priority, 'high');
  assert.equal(tasks[0].reminderLeadMinutes, 60);
  assert.equal(toDateKey(referenceDate), '2026-10-21');
});

test('task storage survives a reload and safely falls back when unavailable', () => {
  const values = new Map<string, string>();
  const storage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => { values.set(key, value); },
  };
  const original = createSeedTasks(referenceDate);
  saveTasksToStorage(storage, original);
  assert.deepEqual(loadTasksFromStorage(storage, referenceDate), original);
  assert.equal(loadTasksFromStorage(null, referenceDate).length, 4);

  const brokenStorage = {
    getItem: () => { throw new Error('Storage blocked'); },
    setItem: () => { throw new Error('Storage full'); },
  };
  assert.equal(loadTasksFromStorage(brokenStorage, referenceDate).length, 4);
  assert.throws(() => saveTasksToStorage(brokenStorage, original));
});

test('backup parsing accepts exported tasks and rejects malformed backups', () => {
  const source = task({ reminderLeadMinutes: 180 });
  const backup = createTaskBackup([source], new Date('2026-10-21T12:00:00.000Z'));
  const restored = parseTaskBackup(backup);
  assert.deepEqual(restored, [source]);
  assert.throws(() => parseTaskBackup('{not json'));
  assert.throws(() => parseTaskBackup(JSON.stringify({ format: 'other', tasks: [] })));
  assert.throws(() => parseTaskBackup(JSON.stringify({ tasks: [{ ...source, dueDate: '2026-02-30' }] })));
  assert.throws(() =>
    parseTaskBackup(JSON.stringify({ tasks: [source, { ...source, title: 'Duplicate ID' }] })),
  );
});
